# Main module
print('hello')
